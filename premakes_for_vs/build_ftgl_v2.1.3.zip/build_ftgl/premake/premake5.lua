--
-- If premake command is not supplied an action (target compiler), exit!
--
-- Target of interest:
--     vs2013     (Visual Studio 2013)
--     vs2015     (Visual Studio 2015)
--     vs2017     (Visual Studio 2017)
--
if (_ACTION == nil) then
    return
end

solution "ftgl"

   --
   -- Build (solution) configuration options:
   --     Release        (Runtime library is Multi-threaded DLL)
   --     Debug          (Runtime library is Multi-threaded Debug DLL)
   --
   configurations { "Release", "Debug" }

   --
   -- destination directory for generated solution/project files
   --
   location ("../" .. _ACTION)

   configuration "Release"
      flags { "Optimize" }

   configuration "Debug"
      flags { "Symbols" }

   --
   -- freeglut library
   --
   project "ftgl"
      -- creating static libraries
      kind "StaticLib"
      -- everything in this project is C++
      language "C++"
      --
      -- destination directory for compiled binary target
      --
      targetdir ("../../lib/")
      --
      files {
         "../../src/**.h",
         "../../src/**.cpp"
      }
      includedirs {
         "../../msvc",
         "../../src"
      }
      defines { "FTGL_LIBRARY_STATIC" }
      configuration "Release"
         targetname "ftgl"
         defines { "WIN32", "_LIB", "NDEBUG" }
      configuration "Debug"
         targetname "ftgl_d"
         defines { "WIN32", "_LIB", "_DEBUG" }


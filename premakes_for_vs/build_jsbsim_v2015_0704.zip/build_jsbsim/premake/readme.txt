
Premake is a tool to generate makefiles and/or visual studio solution/project files.

The OpenEaagles team put together the premake5.lua script for JSBSim to aid in
generating project/solutions files for VS 2013, VS 2015 and 2017.

Included premake is: version 5.0 alpha

Double click make.bat to generate files.



--
-- If premake command is not supplied an action (target compiler), exit!
--
-- Target of interest:
--     vs2012     (Visual Studio 2012)
--     vs2013     (Visual Studio 2013)
--     vs2015     (Visual Studio 2015)
--
if (_ACTION == nil) then
    return
end

--
-- determine target directories for project/solution files and 
-- compiled libraries
--
locationPath  = "../" .. _ACTION
targetLibPath = "../../lib/".._ACTION
if (_ACTION == "codelite") or (_ACTION == "codeblocks") then
  targetLibPath = "../../lib/mingw"
end

solution "jsbsim"

   --
   -- Build (solution) configuration options:
   --     Release        (Runtime library is Multi-threaded DLL)
   --     Debug          (Runtime library is Multi-threaded Debug DLL)
   --
   configurations { "Release", "Debug" }

   --
   -- destination directory for generated solution/project files
   --
   location (locationPath)

   -- C++ code in all projects
   language "C++"

   defines { "HAVE_EXPAT_CONFIG_H" }

   configuration "Release"
      flags { "Optimize" }

   configuration "Debug"
      flags { "Symbols" }

   --
   -- library
   --
   project "jsbsim"
      -- creating static libraries
      kind "StaticLib"
      --
      -- destination directory for compiled binary target
      --
      targetdir (targetLibPath)
      --
      files {
         -- src
         "../../src/*.h",                          "../../src/*.cpp",
         -- src/initialization
         "../../src/initialization/*.h",           "../../src/initialization/*.cpp",
         -- src/input_output
         "../../src/input_output/*.h",             "../../src/input_output/*.cpp",
         "../../src/input_output/*.hxx",
         -- src/math
         "../../src/math/*.h",                     "../../src/math/*.cpp",
         -- src/models
         "../../src/models/*.h",                   "../../src/models/*.cpp",
         -- src/models/atmosphere
         "../../src/models/atmosphere/*.h",        "../../src/models/atmosphere/*.cpp",
         -- src/models/flight_control
         "../../src/models/flight_control/*.h",    "../../src/models/flight_control/*.cpp",
         -- src/models/propulsion
         "../../src/models/propulsion/*.h",        "../../src/models/propulsion/*.cpp",
         -- src/simgear
         "../../src/simgear/*.h",
         -- src/simgear/magvar
         "../../src/simgear/magvar/coremag.cxx",
         "../../src/simgear/magvar/coremag.hxx",
         -- src/simgear/misc
         "../../src/simgear/misc/*.hxx",
         -- src/simgear/props
         "../../src/simgear/props/props.h",        "../../src/simgear/props/props.cxx",
         -- src/simgear/xml
         "../../src/simgear/xml/*.h",
         "../../src/simgear/xml/easyxml.cxx",
         "../../src/simgear/xml/easyxml.hxx",
         "../../src/simgear/xml/xmlparse.c",
         "../../src/simgear/xml/xmlrole.c",
         "../../src/simgear/xml/xmltok.c"
      }
      excludes {
         -- exclude execs
         "../../src/JSBSim.cpp",
         "../../src/JSBSim.minimal.cpp",
         --
         "../../src/initialization/FGTrimAnalysis.*",
         "../../src/initialization/FGTrimAnalysisControl.*"
      }
      includedirs {
         "../../src",
         "../../src/simgear/xml"
      }
      configuration "Release"
         targetname "jsbsim"
         if (_ACTION == "vs2012") or (_ACTION == "vs2013") or (_ACTION == "vs2015") then
            defines { "WIN32", "_LIB", "NDEBUG", "_USE_MATH_DEFINES" }
         end
      configuration "Debug"
         targetname "jsbsim_d"
         if (_ACTION == "vs2012") or (_ACTION == "vs2013") or (_ACTION == "vs2015") then
            defines { "WIN32", "_LIB", "_DEBUG", "_USE_MATH_DEFINES" }
         end

   --
   -- executable
   --
   project "jsbsim-exe"
      kind "ConsoleApp"
      targetname "jsbsim"
      targetdir "../.."
      --
      files {
         "../../src/JSBSim.cpp",
      }
      includedirs {
         "../../src",
         "../../src/simgear/xml"
      }
      libdirs {
         targetLibPath
      }
      configuration "Release"
         if (_ACTION == "vs2012") or (_ACTION == "vs2013") or (_ACTION == "vs2015") then
            defines { "WIN32", "_CONSOLE", "NDEBUG", "_USE_MATH_DEFINES" }
         end
         links {"jsbsim"}
         if (_ACTION == "codeblocks") or (_ACTION == "codelite") then
            links {"wsock32"}
         end
      configuration "Debug"
         if (_ACTION == "vs2012") or (_ACTION == "vs2013") or (_ACTION == "vs2015") then
            defines { "WIN32", "_CONSOLE", "_DEBUG", "_USE_MATH_DEFINES" }
         end
         links {"jsbsim_d"}
         if (_ACTION == "codeblocks") or (_ACTION == "codelite") then
            links {"wsock32"}
         end


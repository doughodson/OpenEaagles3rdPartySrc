--
-- If premake command is not supplied an action (target compiler), exit!
--
-- Target of interest:
--     vs2008     (Visual Studio 2008)
--     vs2010     (Visual Studio 2010)
--     vs2012     (Visual Studio 2012)
--
if (_ACTION == nil) then
    return
end

solution "ftgl"

   --
   -- Build (solution) configuration options:
   --     Release        (Runtime library is Multi-threaded DLL)
   --     Debug          (Runtime library is Multi-threaded Debug DLL)
   --
   configurations { "Release", "Debug" }

   --
   -- destination directory for generated solution/project files
   --
   location ("../" .. _ACTION)

   configuration "Release"
      flags { "Optimize" }

   configuration "Debug"
      flags { "Symbols" }

   --
   -- freeglut library
   --
   project "ftgl_static"
      -- creating static libraries
      kind "StaticLib"
      -- everything in this project is C++
      language "C++"
      --
      -- destination directory for compiled binary target
      --
      targetdir ("../../lib/".._ACTION)
      --
      files {
         "../../src/**.h",
         "../../src/**.cpp"
      }
      includedirs {
         "../../msvc",
         "../../src"
      }
      defines { "FTGL_LIBRARY_STATIC" }
      configuration "Release"
         targetname "ftgl_static"
         if (_ACTION == "vs2008") or (_ACTION == "vs2010") or (_ACTION == "vs2012") then
            defines { "WIN32", "_LIB", "NDEBUG" }
         end
      configuration "Debug"
         targetname "ftgl_static_d"
         if (_ACTION == "vs2008") or (_ACTION == "vs2010") or (_ACTION == "vs2012") then
            defines { "WIN32", "_LIB", "_DEBUG" }
         end

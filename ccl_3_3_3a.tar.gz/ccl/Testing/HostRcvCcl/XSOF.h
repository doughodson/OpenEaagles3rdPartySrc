// XSOF.h: interface for the XSOF class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(_PROC_XSOF_INCLUDED_)
#define _PROC_XSOF_INCLUDED_

#include "CigiBaseEventProcessor.h"
#include "CigiBaseSOF.h"

class XSOF : public CigiBaseEventProcessor
{
public:
   XSOF();
   virtual ~XSOF();

   virtual void OnPacketReceived(CigiBasePacket *Packet);

   void SetOrigPckt(CigiBaseSOF *TPcktIn) { TPckt = TPcktIn; }

protected:
   CigiBaseSOF *TPckt;

};

#endif // _PROC_XSOF_INCLUDED_

--
-- If premake command is not supplied an action (target compiler), exit!
--
-- Target of interest:
--     vs2008     (Visual Studio 2008)
--     vs2010     (Visual Studio 2010)
--     vs2012     (Visual Studio 2012)
--
if (_ACTION == nil) then
   return
end

solution "freetype"

   --
   -- Build (solution) configuration options:
   --     Release        (Runtime library is Multi-threaded DLL)
   --     Debug          (Runtime library is Multi-threaded Debug DLL)
   --
   configurations { "Release", "Debug" }

   --
   -- destination directory for generated solution/project files
   --
   location ("../" .. _ACTION)
   --
   -- destination directory for compiled binary target
   --
   targetdir ("../../lib/".._ACTION)

   configuration "Release"
      flags { "Optimize" }

   configuration "Debug"
      flags { "Symbols" }

   project "freetype"
      kind "StaticLib"
      language "C++"
      files {
         -- FT_MODULES
         "../../src/base/ftbbox.c",
         "../../src/base/ftgxval.c",
         "../../src/base/ftlcdfil.c",
         "../../src/base/ftmm.c",
         "../../src/base/ftotval.c",
         "../../src/base/ftpatent.c",
         "../../src/base/ftpfr.c",
         "../../src/base/ftsynth.c",
         "../../src/base/fttype1.c",
         "../../src/base/ftwinfnt.c",
         "../../src/base/ftxf86.c",
         "../../src/pcf/pcf.c",
         "../../src/pfr/pfr.c",
         "../../src/psaux/psaux.c",
         "../../src/pshinter/pshinter.c",
         "../../src/psnames/psmodule.c",
         "../../src/raster/raster.c",
         "../../src/sfnt/sfnt.c",
         "../../src/truetype/truetype.c",
         "../../src/type1/type1.c",
         "../../src/cid/type1cid.c",
         "../../src/type42/type42.c",
         "../../src/winfonts/winfnt.c",
         -- other
         "../../include/f2build.h",
         "../../include/freetype/config/*.h",
         "../../src/autofit/autofit.c",
         "../../src/bdf/bdf.c",
         "../../src/cff/cff.c",
         "../../src/base/ftbase.c",
         "../../src/base/ftbitmap.c",
         "../../src/cache/ftcache.c",
         "../../builds/win32/ftdebug.c",
         "../../src/base/ftfstype.c",
         "../../src/base/ftgasp.c",
         "../../src/base/ftglyph.c",
         "../../src/gzip/ftgzip.c",
         "../../src/base/ftinit.c",
         "../../src/lzw/ftlzw.c",
         "../../src/base/ftstroke.c",
         "../../src/base/ftsystem.c",
         "../../src/smooth/smooth.c"
      }
      includedirs {
         "../../include"
      }
      configuration "Release"
         -- base filename for compiled binary target
         targetname "freetype2"
         if (_ACTION == "vs2008") or (_ACTION == "vs2010") or (_ACTION == "vs2012") then
            defines { "WIN32", "_LIB", "NDEBUG" }
            defines { "_CRT_SECURE_NO_WARNINGS" }
            defines { "FT2_BUILD_LIBRARY" }
         end
      configuration "Debug"
         -- base filename for compiled binary target
         targetname "freetype2_d"
         if (_ACTION == "vs2008") or (_ACTION == "vs2010") or (_ACTION == "vs2012") then
            defines { "WIN32", "_LIB", "_DEBUG" }
            defines { "_CRT_SECURE_NO_WARNINGS" }
            defines { "FT_DEBUG_LEVEL_ERROR", "FT_DEBUG_LEVEL_TRACE" }
            defines { "FT2_BUILD_LIBRARY", "_CRT_SECURE_NO_DEPRECATE" }
         end

--
-- If premake command is not supplied an action (target compiler), exit!
--
-- Target of interest:
--     vs2010     (Visual Studio 2010)
--     vs2012     (Visual Studio 2012)
--     vs2013     (Visual Studio 2013)
--
if (_ACTION == nil) then
   return
end

solution "ccl_lib"

   --
   -- Build (solution) configuration options:
   --     Release        (Runtime library is Multi-threaded DLL)
   --     Debug          (Runtime library is Multi-threaded Debug DLL)
   --
   configurations { "Release", "Debug" }

   --
   -- destination directory for generated solution/project files
   --
   location ("../" .. _ACTION)
   --
   -- destination directory for compiled binary target
   --
   targetdir ("../../lib/".._ACTION)

   configuration "Release"
      flags { "Optimize" }

   configuration "Debug"
      flags { "Symbols" }

   project "ccl_lib"
      kind "StaticLib"
      language "C++"
      files {
         "../../include/**.h",
         "../../source/**.cpp"
      }
      includedirs {
         "../../include"
      }
      defines { "CIGI_LITTLE_ENDIAN" }
      configuration "Release"
         -- base filename for compiled binary target
         targetname "ccl_lib"
         if (_ACTION == "vs2010") or (_ACTION == "vs2012") or (_ACTION == "vs2013") then
            defines { "WIN32", "_LIB", "NDEBUG" }
         end
      configuration "Debug"
         -- base filename for compiled binary target
         targetname "ccl_lib_d"
         if (_ACTION == "vs2010") or (_ACTION == "vs2012") or (_ACTION == "vs2013") then
            defines { "WIN32", "_LIB", "_DEBUG" }
         end


--
-- If premake command is not supplied an action (target compiler), exit!
--
-- Target of interest:
--     vs2010     (Visual Studio 2010)
--     vs2012     (Visual Studio 2012)
--     vs2013     (Visual Studio 2013)
--
if (_ACTION == nil) then
    return
end

solution "freeglut"

   --
   -- Build (solution) configuration options:
   --     Release        (Runtime library is Multi-threaded DLL)
   --     Debug          (Runtime library is Multi-threaded Debug DLL)
   --
   configurations { "Release", "Debug" }

   --
   -- destination directory for generated solution/project files
   --
   location ("../" .. _ACTION)

   configuration "Release"
      flags { "Optimize" }

   configuration "Debug"
      flags { "Symbols" }

   --
   -- freeglut library
   --
   project "freeglut"
      -- creating static libraries
      kind "StaticLib"
      -- everything in this project is C++
      language "C++"
      --
      -- destination directory for compiled binary target
      --
      targetdir ("../../lib/".._ACTION)
      --
      files {
         "../../src/*.c",
         "../../src/*.h",
         "../../include/GL/*.h"
      }
      excludes {
         "../../src/freeglut_xinput.c"
      }
      includedirs {
         "../../include"
      }
      defines { "FREEGLUT_STATIC", "FREEGLUT_LIB_PRAGMAS=0" }
      configuration "Release"
         targetname "freeglut"
         if (_ACTION == "vs2010") or (_ACTION == "vs2012") or (_ACTION == "vs2013") then
            defines { "WIN32", "_LIB", "NDEBUG" }
         end
      configuration "Debug"
         targetname "freeglut_d"
         if (_ACTION == "vs2010") or (_ACTION == "vs2012") or (_ACTION == "vs2013") then
            defines { "WIN32", "_LIB", "_DEBUG" }
         end


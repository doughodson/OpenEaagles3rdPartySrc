
Premake is a tool to generate makefiles and/or visual studio solution/project files.

The OpenEaagles team put together the premake5.lua script for JSBSim to aid in
generating project/solutions files for VS 2010, VS 2012 and 2013.

Included premake is: version 5.0 alpha

Double click make.bat to generate files.



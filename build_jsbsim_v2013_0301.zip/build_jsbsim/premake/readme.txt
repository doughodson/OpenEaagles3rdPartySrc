
Premake is a tool to generate makefiles and/or visual studio solution/project files.

The OpenEaagles team put together the premake4.lua script for JSBSim to aid in
generating project/solutions files for VS 2008 and 2010.

Included premake is: version 4.4-beta 1.

Double click make.bat to generate files.

NOTE: If you are using this code with another version of JSBSim, please read note
      in the file premake4.lua !!


